let gameScene = new Phaser.Scene('Game');


gameScene.init = function() {
  
}

gameScene.preload = function() {

  // load images
  this.load.image('background', 'assets/ground.png');
  this.load.spritesheet('stun', 'assets/stunfisk.png', {frameWidth: 77, frameHeight: 32});
  this.load.spritesheet('char', 'assets/charizard.png', {frameWidth: 89, frameHeight: 91});
  this.load.image('enemyhealth', 'assets/enemyhealth.png');
  this.load.image('pokehealth', 'assets/pokehealth.png');
  this.load.image('attacks', 'assets/attacks.png');
  this.load.image('green', 'assets/healthgreen.png');
  this.load.image('yellow', 'assets/healthyellow.png');
  this.load.image('red', 'assets/healthred.png');
  //this.load.spritesheet('health', 'assets/health.png', {frameWidth: 112, frameHeight: 36});
  
  



};

gameScene.create = function() {

  // *** game create code goes here ***
  //background
  let bg = this.add.sprite(0, 0, 'background');
  bg.setScale(3.0);
  
  //change origin to the top-left of the sprite
  bg.setOrigin(0,0);
  this.player = this.add.sprite(150, this.sys.game.config.height / 1.2,'stun');
  this.enemies = this.add.sprite(550, this.sys.game.config.height / 3.5,'char');
  let green = this.add.sprite(0, 0, 'green');
  green.setOrigin(-1.4,-17.56);
  green.setScale(1.8)
  let yellow = this.add.sprite(0, 0, 'yellow');
  yellow.setOrigin(-2,-17.56);
  yellow.setScale(1.8)
  let red = this.add.sprite(0, 0, 'red');
  red.setOrigin(-10.5,-17.56);//-10.5 -17.5
  red.setScale(1.8)
  
  this.anims.create({
	  key: 'float',
	  frames:this.anims.generateFrameNumbers('stun', {start: 0, end: 124}),
	  frameRate: 24,
	  repeat: -1
  });
  this.anims.create({
	  key: 'wiggle',
	  frames:this.anims.generateFrameNumbers('char', {start: 0, end: 142}),
	  frameRate: 24,
	  repeat: -1
  });
  this.anims.create({
	  key: 'health',
	  frames:this.anims.generateFrameNumbers('health', {start: 0, end: 2}),
	  frameRate: 1,
	  repeat: -1
  });
  this.player.anims.play('float');
  //this.health.anims.play('health');
  this.player.setScale(4);
  this.enemies.anims.play('wiggle');
  this.enemies.setScale(2);
  
  


  
   let eh = this.add.sprite(0, 0, 'enemyhealth');
   eh.setScale(1.8);
   eh.setOrigin(-.2,-1);
   let ph = this.add.sprite(0, 0, 'pokehealth');
   ph.setScale(1.5)
   ph.setOrigin(-3.3,-3.2);

  
  let attack = this.add.sprite(0, 0, 'attacks');
  attack.setScale(1.3);
  attack.setOrigin(-1.31,-3.2);
  let earth = this.add.text(528, 245, 'Earthquake', { fontSize: '13px', fill: '#000' });
  earth.setOrigin(-1.31,-3.2);
  
  let thunderbolt = this.add.text(517, 272, 'Thunderbolt', { fontSize: '13px', fill: '#000' });
  thunderbolt.setOrigin(-1.31,-3.2);
  
  let sandstorm = this.add.text(538, 313, 'Sandstorm', { fontSize: '13px', fill: '#000' });
  thunderbolt.setOrigin(-1.31,-3.2);
  
  let discharge = this.add.text(305, 245, 'Discharge', { fontSize: '13px', fill: '#000' });
  discharge.setOrigin(-1.31,-3.2);
  
  let charizard = this.add.text(55, 73, 'Charizard', { fontSize: '18px', fill: '#000' });
  discharge.setOrigin(-.2,-1);
  
  let stunfisk = this.add.text(568, 225, 'Stunfisk', { fontSize: '18px', fill: '#000' });
  discharge.setOrigin(-3.3,-3.2);
  
  // var barConfig = {x: 200, y: 100};
	// this.myHealthBar = new HealthBar(this.gameScene, barConfig);
	
};
  


gameScene.update = function() {
	// *** game update code goes here ***
	//only is the player is alive
	cursors = this.input.keyboard.createCursorKeys();
	if (cursors.right.isDown)
{
	this.cameras.main.shake(1000);
	// this.camera.main.resetFX();
}
else if (cursors.left.isDown)
{
	this.cameras.main.flash(500);
	
	this.cameras.main.shake(1000);
	
}
else if (cursors.up.isDown)
{
	this.cameras.main.flash(500);
	
	this.cameras.main.shake(1000);
}
else if (cursors.down.isDown)
{
	this.cameras.main.flash(1000)
	
}
else 
{
    
};
//this.myHealthBar.kill();
};





gameScene.gameOver = function() {

  	// *** game over code goes here ***
	//flag to set player is dead

};

let config = {
  type: Phaser.AUTO,
  width: 720,
  height: 336,
  scene: gameScene
};

let game = new Phaser.Game(config);