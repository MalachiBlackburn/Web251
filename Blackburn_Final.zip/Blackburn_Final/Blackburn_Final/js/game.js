let gameScene = new Phaser.Scene('Game');


gameScene.init = function() {
  
}

gameScene.preload = function() {

  // load images
  this.load.image('background', 'assets/ground.png');
  this.load.spritesheet('stun', 'assets/stunfisk.png', {frameWidth: 77, frameHeight: 32});
  this.load.spritesheet('char', 'assets/charizard.png', {frameWidth: 89, frameHeight: 91});
  this.load.image('enemyhealth', 'assets/enemyhealth.png');
  this.load.image('pokehealth', 'assets/pokehealth.png');
  this.load.image('attacks', 'assets/attacks.png');

};

gameScene.create = function() {

  // *** game create code goes here ***
  //background
  let bg = this.add.sprite(0, 0, 'background');
  bg.setScale(3.0);
  
  //change origin to the top-left of the sprite
  bg.setOrigin(0,0);
  this.player = this.add.sprite(150, this.sys.game.config.height / 1.2,'stun');
  this.enemies = this.add.sprite(550, this.sys.game.config.height / 3.5,'char');
  
  this.anims.create({
	  key: 'float',
	  frames:this.anims.generateFrameNumbers('stun', {start: 0, end: 124}),
	  frameRate: 24,
	  repeat: -1
  });
  this.anims.create({
	  key: 'wiggle',
	  frames:this.anims.generateFrameNumbers('char', {start: 0, end: 142}),
	  frameRate: 24,
	  repeat: -1
  });
  this.player.anims.play('float');
  this.player.setScale(4);
  this.enemies.anims.play('wiggle');
  this.enemies.setScale(2);
  
   let eh = this.add.sprite(0, 0, 'enemyhealth');
   eh.setScale(1.8);
   eh.setOrigin(-.2,-1);
   let ph = this.add.sprite(0, 0, 'pokehealth');
   ph.setScale(1.5)
   ph.setOrigin(-3.3,-3.2);
  
  let attack = this.add.sprite(0, 0, 'attacks');
  attack.setScale(1.3);
  attack.setOrigin(-1.24,-3.9);
  
  
  
  
};

gameScene.update = function() {
	// *** game update code goes here ***
	//only is the player is alive
	cursors = this.input.keyboard.createCursorKeys();
	if (cursors.right.isDown)
{
	this.cameras.main.shake(500);
	// this.camera.main.resetFX();
}
else if (cursors.left.isDown)
{
	
}
else if (cursors.up.isDown)
{
	
}
else 
{
    
	
	
};
};

gameScene.gameOver = function() {

  	// *** game over code goes here ***
	//flag to set player is dead

};

let config = {
  type: Phaser.AUTO,
  width: 720,
  height: 336,
  scene: gameScene
};

let game = new Phaser.Game(config);