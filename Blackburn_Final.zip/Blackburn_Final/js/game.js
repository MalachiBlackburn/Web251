let gameScene = new Phaser.Scene('Game');


gameScene.init = function() {
  
}

gameScene.preload = function() {

  // load images
  this.load.image('background', 'assets/ground.png');
  this.load.spritesheet('stun', 'assets/stunfisk.png', {frameWidth: 77, frameHeight: 32});
  this.load.spritesheet('char', 'assets/charizard.png', {frameWidth: 89, frameHeight: 91});
  

};

gameScene.create = function() {

  // *** game create code goes here ***
  //background
  let bg = this.add.sprite(0, 0, 'background');
  bg.setScale(3.0);
  
  //change origin to the top-left of the sprite
  bg.setOrigin(0,0);
  this.player = this.add.sprite(150, this.sys.game.config.height / 1.2,'stun');
  this.enemies = this.add.sprite(550, this.sys.game.config.height / 3.5,'char');
  //this.player.setOrigin(-1,-3);
  
  //this.player.setScale(2.0);
  this.anims.create({
	  key: 'float',
	  frames:this.anims.generateFrameNumbers('stun', {start: 0, end: 124}),
	  frameRate: 24,
	  repeat: -1
  });
  this.anims.create({
	  key: 'wiggle',
	  frames:this.anims.generateFrameNumbers('char', {start: 0, end: 142}),
	  frameRate: 24,
	  repeat: -1
  });
  this.player.anims.play('float');
  this.player.setScale(4);
  this.enemies.anims.play('wiggle');
  this.enemies.setScale(2);
  
};

gameScene.update = function() {
	// *** game update code goes here ***
	//only is the player is alive
	
	
};

gameScene.gameOver = function() {

  	// *** game over code goes here ***
	//flag to set player is dead

};

let config = {
  type: Phaser.AUTO,
  width: 720,
  height: 336,
  scene: gameScene
};

let game = new Phaser.Game(config);