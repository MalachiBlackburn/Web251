
// M7LAB
// Your Name
// Starter code -- add to the functions below.


// create a new scene named "Game"
let gameScene = new Phaser.Scene('Game');


// some parameters for our scene
gameScene.init = function() {
  this.playerSpeed = 1.5;
  this.enemySpeed = 2;
  this.enemyMaxY = 280;
  this.enemyMinY = 80;
}

// load asset files for our game
gameScene.preload = function() {

  // load images
  this.load.image('background', 'assets/background.png');
  this.load.spritesheet('player', 'assets/stance.png', {frameWidth: 25, frameHeight: 47} );
  this.load.spritesheet('run', 'assets/run.png', {frameWidth: 38, frameHeight: 47} );
  this.load.spritesheet('runback', 'assets/runback.png', {frameWidth: 38, frameHeight: 47} );
  this.load.spritesheet('dragon', 'assets/sound.png', {frameWidth: 42, frameHeight: 47});
  this.load.image('treasure', 'assets/scroll.png');
  //sasuke res = 25x47 columns 4
};

// executed once, after assets were loaded
gameScene.create = function() {

  // *** game create code goes here ***
  //background
  let bg = this.add.sprite(0, 0, 'background');
  
  //change origin to the top-left of the sprite
  bg.setOrigin(0,0);
  
  //player
  //this.player = this.add.sprite(40, this.sys.game.config.height / 2,'player');
  this.player = this.add.sprite(40, this.sys.game.config.height / 2,'run');
  this.anims.create({
	  key: 'stand',
	  frames:this.anims.generateFrameNumbers('player', {start: 0, end: 3}),
	  frameRate: 7,
	  repeat: -1
  });
  this.anims.create({
	  key: 'right',
	  frames:this.anims.generateFrameNumbers('run', {start: 0, end: 1}),
	  frameRate: 12,
	  repeat: -1
  });
  this.anims.create({
	  key: 'left',
	  frames:this.anims.generateFrameNumbers('runback', {start: 0, end: 1}),
	  frameRate: 12,
	  repeat: -1
  });
  this.anims.create({
	  key: 'walk',
	  frames:this.anims.generateFrameNumbers('sound', {start: 0, end: 5}),
	  frameRate: 7,
	  repeat: -1
  });
  
  
  //scale down
  this.player.setScale(1);
  
  //goal
  this.treasure = this.add.sprite(this.sys.game.config.width - 80, this.sys.game.config.height / 2, 'treasure');
  this.treasure.setScale(0.9);
  
  //group of enemies
  this.enemies = this.add.group({
	  key: 'dragon',
	  repeat:5,
	  setXY: {
		  x:110,
		  y:100,
		  stepX: 80,
		  stepY: 20
	  }
  });
  
  //scale enemies
  Phaser.Actions.ScaleXY(this.enemies.getChildren(), -.3, -.3);
  //set speeds
  Phaser.Actions.Call(this.enemies.getChildren(), function(enemy) {
	  enemy.speed = Math.random() *2 +1;
  }, this);
  //player is alive
  this.isPlayerAlive = true;
  //reset camera effects
  this.cameras.main.resetFX();
  
};

// executed on every frame (60 times per second)
gameScene.update = function() {
	// *** game update code goes here ***
	//only is the player is alive
	if(!this.isPlayerAlive) {
		return;
	}
	//enemy movement and collision
	let enemies = this.enemies.getChildren();
	let numEnemies = enemies.length;
	
	
	for (let i = 0; i < numEnemies; i++) {
		
		//move enemies
		enemies[i].y += enemies[i].speed;
		//this.enemies.anims.play('walk', true);
		
		//reverse movement if reached the edges
		if (enemies[i].y >= this.enemyMaxY && enemies[i].speed > 0) {
			enemies[i].speed *= -1;
		} else if (enemies[i].y <= this.enemyMinY && enemies[i].speed < 0) {
			enemies[i].speed *= -1;
		}
	
	
		//enemy collision
		if (Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(), enemies[i].getBounds())) {
			this.gameOver();
		
		}
	}
	cursors = this.input.keyboard.createCursorKeys();
	if (cursors.right.isDown)
{
	this.player.x += this.playerSpeed;
    this.player.anims.play('right', true);
}
else if (cursors.left.isDown)
{
	this.player.x -= this.playerSpeed;
    this.player.anims.play('left', true);
}
else
{
    this.player.anims.play('stand');
}
	
	//executed on every frame (60 fps)
	//if (this.input.activePointer.isDown){
		
		//player walks
		//this.player.x += this.playerSpeed;
	//}
	//treasure collection
	if (Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(), this.treasure.getBounds())) {
		this.gameOver();
	}
};

gameScene.gameOver = function() {

  	// *** game over code goes here ***
	//flag to set player is dead
	this.isPlayerAlive = false;
	//shake the camera
	this.cameras.main.shake(500);
	//fade camera
	this.time.delayedCall(250, function() {
		this.cameras.main.fade(250);
	}, [], this);
	
	//restart the game
	this.time.delayedCall(500, function() {
		this.scene.restart();
	},[], this);
};



// our game's configuration
let config = {
  type: Phaser.AUTO,
  width: 640,
  height: 360,
  scene: gameScene
};

// create the game, and pass it the configuration
let game = new Phaser.Game(config);
